<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Country";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$searchInput = $_POST['searchInput'];

$sql = "SELECT id, name, department, birth FROM Citizen WHERE name LIKE '%$searchInput%'";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    echo "<h2>Matching Citizens:</h2>";
    while ($row = $result->fetch_assoc()) {
        echo "<p>ID: " . $row["id"] . "</p>";
        echo "<p>Name: " . $row["name"] . "</p>";
        echo "<p>Department: " . $row["department"] . "</p>";
        echo "<p>Date of Birth: " . $row["birth"] . "</p>";
        echo "<hr>";
    }
} else {
    echo "<p>No matching citizens found.</p>";
}

$conn->close();
?>
