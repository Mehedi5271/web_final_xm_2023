<?php
function generateCrypticSequence($seed, $numTerms) {
    $sequence = [$seed]; 

    for ($i = 1; $i < $numTerms; $i++) {
        $previousNumber = $sequence[$i - 1];
        $productOfDigits = 1;

       
        $digits = str_split(strval($previousNumber));
        foreach ($digits as $digit) {
            $productOfDigits *= intval($digit);
        }

       
        $nextNumber = $previousNumber + $productOfDigits;

        
        $sequence[] = $nextNumber;
    }

    return $sequence;
}

$seed = 7; 
$numTerms = 5; 
if (isset($_POST['seed']) && isset($_POST['numTerms'])) {
    $seed = intval($_POST['seed']);
    $numTerms = intval($_POST['numTerms']);
}

$crypticSequence = generateCrypticSequence($seed, $numTerms);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Cryptic Sequence Generator</title>
</head>
<body>
    <h1>Cryptic Sequence Generator</h1>
    <form method="POST">
        <label for="seed">Seed Value:</label>
        <input type="number" name="seed" value="<?php echo $seed; ?>" required>
        <br>
        <label for="numTerms">Number of Terms:</label>
        <input type="number" name="numTerms" value="<?php echo $numTerms; ?>" required>
        <br>
        <input type="submit" value="Generate Sequence">
    </form>
    
    <p>Cryptic Sequence: <?php echo implode(', ', $crypticSequence); ?></p>
</body>
</html>
